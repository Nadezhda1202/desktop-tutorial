# host = 'http://192.168.1.111:4500' #хост оркестратора
# robot_guid = GUID робота

# req_param = {
#     'RobotGUID': GUID робота
#     'Machine': Имя машины
#     'IP': IP адрес робота
#     'MAC': MAC адрес робота
#     'Status': статус робота
#     'JobGUID': GUID работы
#     'JobName': название выполняемого скрипта, т.е. python_script_name далее по тексту
#     'JobType': тип работы, всегда значение 1
# }'''

# headers = {'Authorization': 'Basic ' + base64.b64encode(robot_guid.encode('utf-8')).decode('utf-8')}

# Статусы роботов
# Status_Disconnected   = 0;  робот отключен
# Status_Unlicensed     = 1;  робот не лицензирован
# Status_Ready          = 2;  робот не выполняет работы и готов к приему новых работ
# Status_Working        = 3;  робот выполняет текущую работу

# Статусы ErrorCode
# HeartbeatErrorCode_NoError       = 0;   нет ошибок
# HeartbeatErrorCode_RobotNotFound = 101; робот с указанным GUID не найден
# HeartbeatErrorCode_JobAborting   = 10;  оркестратор запросил жесткую остановку данного сценария (Abort)
# HeartbeatErrorCode_JobStopping   = 20;  оркестратор запросил мягкую остановку данного сценария (Stop)

# Статусы HasNewJob
# HasNewJob_NoJob       = 0     для данного робота отсутствуют новые работы
# HasNewJob_JobFound    = 1     для данного робота есть новые работы, которые необходимо получить с помощью вызова ConsumeNextJob

# ConsumeJobErrorCode   = 0;    нет ошибок
# ConsumeJobErrorCode   = 101;  робот с указанным GUID не найден
# ConsumeJobErrorCode   = 102;  новая работа не найдена

# Status_Created        = 0;    Работа создана
# Status_Pending        = 1;    Работа ожидает, когда робот возьмет её в работу
# Status_Aborting       = 2;    Работа находится в стадии жесткой остановки (прерывания)
# Status_Aborted        = 3;    Работа успешно прервана
# Status_Success        = 4;    Работа успешно завершена
# Status_Failed         = 5;    Работа неуспешно завершена
# Status_Stopping       = 6;    Работа находится в стадии остановки мягкой остановки
# Status_Stopped        = 7;    Работа успешно остановлена после запроса мягкой остановки
# Status_In_Progress    = 8;    Работа в данный момент выполняется

import requests
import urllib3
import json

class RobotsOrchestratorAPI():
    def __init__(self, robot_guid, host, headers):
        requests.packages.urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        self.robot_guid, self.host, self.headers = robot_guid, host, headers
    
    def request_heartbeat(self, req_param, script='/api/robot/heartbeat'):
        req_result = requests.post(
            self.host + script, data = req_param,
            headers = self.headers, verify = False
        )
        return json.loads(req_result.text)

    def request_consumeNextJob(self, status, script='/api/robot/consumeNextJob'):
        req_result = requests.post(
            self.host + script, data = {'RobotGUID': self.robot_guid, "Status": status},
            headers = self.headers, verify = False
        )
        consume_result = json.loads(req_result.text)
        
        #Условимся, что имя скрипта робота, который необходимо запустить, передаётся в названии версии процесса
        if consume_result["ConsumeJobErrorCode"] == 102: return consume_result["ErrorText"]

        new_job = consume_result['Job']
        job_guid = new_job['GUID']
        process_version = consume_result['ProcessVersion']
        JobName = process_version['Name']
        task = consume_result['Task']

        return {
            'new_job': new_job, 'JobGUID': job_guid,
            'process_version': consume_result['ProcessVersion'],
            'JobName': JobName, 'task': task
        }

    def request_update(self, job_GUID, status=0):
        req_result = requests.put(
            self.host + '/api/job/update',
            data={'guid': job_GUID, 'status': status},
            headers=self.headers, verify=False
        )

        return req_result
